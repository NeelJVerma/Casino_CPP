#include "computer.h"
#include <iostream>

bool Computer::MakeMove(std::shared_ptr<Table>& table) {
  for (unsigned i = 0; i < hand_.size(); i++) {
    FindBestMoveWithCard(hand_[i], table);
  }

  return true;
}

void Computer::FindBestMoveWithCard(
    const std::shared_ptr<Card>& card,
    const std::shared_ptr<Table>& table) const {
  // find all loose cards
  FindAllLooseCardsWithCard(card, table);

  // find all sets
  FindAllSubsetsWithCard(card, table);
  
  // find all builds
  FindAllBuildsWithCard(card, table);
}

void Computer::FindAllLooseCardsWithCard(
    const std::shared_ptr<Card>& card,
    const std::shared_ptr<Table>& table) const {
  auto loose_cards = table->GetLooseCards();

  for (unsigned i = 0; i < loose_cards.size(); i++) {
    if ((card->GetValue() == loose_cards[i]->GetValue()) ||
        (card->IsAce() && loose_cards[i]->IsAce())) {
      std::cout << card->ToString() << ' ' << loose_cards[i]->ToString() << std::endl;
    }
  }
}

void Computer::FindAllSubsetsWithCard(
    const std::shared_ptr<Card>& card,
    const std::shared_ptr<Table>& table) const {
  auto loose_cards = table->GetLooseCards();
  unsigned num_subsets = 1 << loose_cards.size();
  
  for (unsigned i = 0; i < num_subsets; i++) {
    std::vector<std::string> subset;
    unsigned sum = 0;

    for (unsigned j = 0; j < loose_cards.size(); j++) {
      if (i & (1 << j)) {
        subset.push_back(loose_cards[j]->ToString());
        sum += loose_cards[j]->GetValue();
      }
    }

    if (subset.size() == 1) {
      continue;
    }

    if (sum == card->GetValue()) {
      for (unsigned j = 0; j < subset.size(); j++) {
        std::cout << subset[j] << ' ';
      }

      std::cout << std::endl;
    }
  }
}

void Computer::FindAllBuildsWithCard(
    const std::shared_ptr<Card>& card,
    const std::shared_ptr<Table>& table) const {
  auto builds = table->GetCurrentBuilds();

  for (unsigned i = 0; i < builds.size(); i++) {
    if (card->GetValue() == builds[i]->GetBuildSum()) {
      std::cout << card->ToString() << ' ' << builds[i]->ToString() << std::endl;
    }
  }
}