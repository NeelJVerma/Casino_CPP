#include <algorithm>
#include <unordered_set>
#include "table.h"
#include "inputhandler.h"

void Table::AddDealtCards(const std::vector<std::shared_ptr<Card>>& dealt) {
  for (unsigned i = 0; i < dealt.size(); i++) {
    loose_cards_.push_back(dealt[i]);
  }
}

bool Table::ValueMatchesLooseCard(const unsigned& card_value) const {
  for (unsigned i = 0; i < loose_cards_.size(); i++) {
    if (card_value == loose_cards_[i]->GetValue()) {
      return true;
    }
  }

  return false;
}

bool Table::ValueMatchesBuild(
    const unsigned& card_value, const unsigned& player_number) const {
  for (unsigned i = 0; i < current_builds_.size(); i++) {
    if (current_builds_[i]->GetOwnerIndex() != player_number) {
      continue;
    }

    if (current_builds_[i]->GetBuildSum() == card_value) {
      return true;
    }
  }

  return false;
}

bool Table::PlayerOwnsAnyBuilds(const unsigned& player_number) const {
  for (unsigned i = 0; i < current_builds_.size(); i++) {
    if (current_builds_[i]->GetOwnerIndex() == player_number) {
      return true;
    }
  }

  return false;
}

bool Table::CardsOnTable(
    const std::vector<std::string>& cards,
    std::vector<unsigned>& card_indices) const {
  for (unsigned i = 0; i < loose_cards_.size(); i++) {
    auto card = loose_cards_[i];

    if (find(cards.begin(), cards.end(), card->ToString()) != cards.end()) {
      if (card->IsAce()) {
        card->SetValue(InputHandler::GetAceInput(card->ToString()));
      }

      card_indices.push_back(i);
    }
  }

  return card_indices.size() == cards.size();
}

bool Table::CardsInBuild(
    const std::vector<std::string>& cards, unsigned& build_index) const {
  std::unordered_set<std::string> seen;

  for (unsigned i = 0; i < cards.size(); i++) {
    seen.insert(cards[i]);
  }

  for (unsigned i = 0; i < current_builds_.size(); i++) {
    std::unordered_set<std::string> seen_on_table;
    auto current_build = current_builds_[i];

    for (unsigned j = 0; j < current_build->GetBuildSize(); j++) {
      for (unsigned k = 0; k < current_build->GetBuildAt(j).size(); k++) {
        std::string card_str = current_build->GetBuildAt(j)[k]->ToString();

        if (seen.find(card_str) == seen.end()) {
          seen_on_table.clear();
          break;
        }

        seen_on_table.insert(card_str);
      }
    }

    if (seen_on_table.size() == seen.size()) {
      build_index = i;
      return true;
    }
  }

  return false;
}

void Table::RemoveLooseCards(const std::vector<unsigned>& indices) {
  std::vector<std::shared_ptr<Card>> temp;

  for (unsigned i = 0; i < loose_cards_.size(); i++) {
    if (find(indices.begin(), indices.end(), i) == indices.end()) {
      temp.push_back(loose_cards_[i]);
    }
  }

  loose_cards_.clear();

  for (unsigned i = 0; i < temp.size(); i++) {
    loose_cards_.push_back(temp[i]);
  }
}

void Table::RemoveMultipleBuilds(const std::vector<unsigned>& indices) {
  std::vector<std::shared_ptr<Build>> temp;

  for (unsigned i = 0; i < current_builds_.size(); i++) {
    if (find(indices.begin(), indices.end(), i) == indices.end()) {
      temp.push_back(current_builds_[i]);
    }
  }

  current_builds_.clear();

  for (unsigned i = 0; i < temp.size(); i++) {
    current_builds_.push_back(temp[i]);
  }
}

std::vector<std::shared_ptr<Card>> Table::DeconstructBuild(
    const unsigned& index) {
  std::vector<std::shared_ptr<Card>> cards;

  for (unsigned i = 0; i < current_builds_[index]->GetBuildSize(); i++) {
    for (auto card : current_builds_[index]->GetBuildAt(i)) {
      cards.push_back(card);
    }
  }

  return cards;
}

bool Table::HasAces() const {
  for (unsigned i = 0; i < loose_cards_.size(); i++) {
    if (loose_cards_[i]->IsAce()) {
      return true;
    }
  }

  return false;
}

std::vector<std::shared_ptr<Card>> Table::ClearTable() {
  std::vector<std::shared_ptr<Card>> cards;

  for (unsigned i = 0; i < loose_cards_.size(); i++) {
    cards.push_back(loose_cards_[i]);
  }

  loose_cards_.clear();

  return cards;
}

std::string Table::ToString() const {
  std::string table = "Table: ";

  for (unsigned i = 0; i < current_builds_.size(); i++) {
    table += current_builds_[i]->ToString();
  }

  for (unsigned i = 0; i < loose_cards_.size(); i++) {
    table += loose_cards_[i]->ToString() + " ";
  }

  return table;
}