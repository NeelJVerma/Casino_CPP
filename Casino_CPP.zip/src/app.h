#ifndef _APP_H_
#define _APP_H_

#include <fstream>
#include "tournament.h"

class App {
 public:
  // Delete copy constructor and assignment operator
  App(const App& app) = delete;
  App& operator=(const App& app) = delete;

  App() = default;
  void Start();

 private:
  enum LoadOption {
    kLoad = 1,
    kNew
  };

  void SetPlayerDataFromFile(std::ifstream& in_file);
  std::shared_ptr<Tournament> tournament_;
};

#endif