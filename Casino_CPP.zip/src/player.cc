/*******************************
 * Name: Neel Verma            *
 * Project: Casino CPP         *
 * Class: CMPS 366-01          *
 * Due Date: 10/2/18           *
 *******************************/

#include "player.h"
#include "inputhandler.h"

/**
 * Description: Removes the card at index from the hand.
 * Parameters: const unsigned& index: The index of the card to remove.
 * Returns: An pointer to the card that was removed.
 */

std::shared_ptr<Card> Player::RemoveFromHand(const unsigned& index) {
  std::shared_ptr<Card> return_card = hand_[index];
  hand_.erase(hand_.begin() + index);

  return return_card;
}

/**
 * Description: Converts all player information to a string.
 * Parameters: None.
 * Returns: The string format of a player.
 */

std::string Player::ToString() const {
  std::string player = "";
  player += (is_human_ ? "Human:\n" : "Computer:\n");
  player += "\tScore: ";
  player += std::to_string(score_);
  player += "\n\tHand: ";

  for (auto card : hand_) {
    player += card->ToString() + ' ';
  }

  player += "\n\tPile: ";

  for (auto card : pile_) {
    player += card->ToString() + ' ';
  }

  player += '\n';

  return player;
}

void Player::TrailAction(
    const unsigned& card_index, std::shared_ptr<Table>& table) {
  std::shared_ptr<Card> card = RemoveFromHand(card_index);
  table->AddLooseCard(card);
}

void Player::MakeBuildAction(
    const unsigned& card_index,
    const std::vector<std::shared_ptr<Card>>& cards,
    const std::vector<unsigned>& card_indices, const unsigned& build_sum,
    std::shared_ptr<Table>& table) {
  std::shared_ptr<Build> build(new Build);
  RemoveFromHand(card_index);
  build->AddToBuild(cards);
  build->SetBuildSum(build_sum);
  table->RemoveLooseCards(card_indices);
  table->AddBuild(build);
  build->SetOwnerIndex(number_);
}

void Player::IncreaseBuildAction(
      const unsigned& card_index, std::shared_ptr<Build> build,
      const unsigned& build_sum, std::shared_ptr<Table>& table) {
  build->AddToSingleBuild(hand_[card_index]);
  RemoveFromHand(card_index);
  build->SetBuildSum(build_sum);
  build->SetOwnerIndex(number_);
}

void Player::AddToBuildAction(
    const unsigned& card_index, std::shared_ptr<Build> build,
    const std::vector<std::shared_ptr<Card>>& cards,
    const std::vector<unsigned>& card_indices, std::shared_ptr<Table>& table) {
  RemoveFromHand(card_index);
  build->AddToBuild(cards);
  table->RemoveLooseCards(card_indices);
  build->SetOwnerIndex(number_);
}

void Player::CaptureSetAction(
    const std::vector<unsigned>& card_indices, std::shared_ptr<Table>& table) {
  for (unsigned i = 0; i < card_indices.size(); i++) {
    pile_.push_back(table->GetLooseCard(card_indices[i]));
  }

  table->RemoveLooseCards(card_indices);
}

void Player::CaptureBuildAction(
    const unsigned& build_index,
    std::shared_ptr<Table>& table) {
  auto deconstructed_build = table->DeconstructBuild(build_index);

  for (unsigned i = 0; i < deconstructed_build.size(); i++) {
    pile_.push_back(deconstructed_build[i]);
  }

  table->RemoveBuild(build_index);
}

bool Player::CaptureAllCardsWithSameValue(
    const unsigned& card_index, std::shared_ptr<Table>& table) {
  bool matches = false;
  unsigned value = hand_[card_index]->GetValue();
  auto card_in_hand = hand_[card_index];
  std::vector<unsigned> card_indices;

  for (unsigned i = 0; i < table->GetLooseCards().size(); i++) {
    auto card_on_table = table->GetLooseCards()[i];

    if ((card_on_table->IsAce() && card_in_hand->IsAce()) ||
        (card_on_table->GetValue() == value)) {
      pile_.push_back(card_on_table);
      card_indices.push_back(i);
      matches = true;
    }
  }

  table->RemoveLooseCards(card_indices);

  return matches;
}

bool Player::CaptureAllBuildsWithSameValue(
    const unsigned& card_index, std::shared_ptr<Table>& table) {
  bool matches = false;
  unsigned value = hand_[card_index]->GetValue();
  auto card_in_hand = hand_[card_index];
  std::vector<unsigned> build_indices;

  for (unsigned i = 0; i < table->GetCurrentBuilds().size(); i++) {
    auto build = table->GetCurrentBuilds()[i];

    if (build->GetOwnerIndex() != number_) {
      continue;
    }

    if (build->GetBuildSum() == value) {
      auto deconstructed_build = table->DeconstructBuild(i);

      for (unsigned j = 0; j < deconstructed_build.size(); j++) {
        pile_.push_back(deconstructed_build[j]);
      }

      build_indices.push_back(i);
      matches = true;
    }
  }

  table->RemoveMultipleBuilds(build_indices);

  return matches;
}

bool Player::HasCardWithBuildSum(
    const unsigned& card_index, const unsigned& build_sum) const {
  for (unsigned i = 0; i < hand_.size(); i++) {
    auto card = hand_[i];

    if (i != card_index && card->IsAce()) {
      card->SetValue(InputHandler::GetAceInput(card->ToString()));
    }

    if (i != card_index && card->GetValue() == build_sum) {
      return true;
    }
  }

  return false;
}

bool Player::HasMultipleOfSameCard(const unsigned& card_index) const {
  unsigned value = hand_[card_index]->GetValue();

  for (unsigned i = 0; i < hand_.size(); i++) {
    if (i == card_index) {
      continue;
    }

    if (value == hand_[i]->GetValue()) {
      return true;
    }
  }

  return false;
}