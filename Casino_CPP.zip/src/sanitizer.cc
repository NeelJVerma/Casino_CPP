#include <sstream>
#include <algorithm>
#include <iterator>
#include <vector>
#include <unordered_set>
#include "sanitizer.h"

static const char kSuits[Card::kNumSuits] = {'H', 'S', 'C', 'D'};
static const char kValues[Card::kNumValues] =
    {'A', '2', '3', '4', '5', '6', '7', '8', '9', 'X', 'J', 'Q', 'K'};
static const unsigned kNumMoveDirectives = 3;
static const unsigned kMaxMenuChoices = 4;
static const unsigned kNumAceChoices = 2;
static const unsigned kNumBuildChoices = 3;
static const unsigned kNumCaptureChoices = 3;
static const unsigned kNumDeckChoices = 2;
static const unsigned kNumLoadChoices = 2;
static const std::string kMoveDirectives[kNumMoveDirectives] = {"1", "2", "3"};
static const std::string kMenuChoices[kMaxMenuChoices] = {"1", "2", "3", "4"};
static const std::string kAceChoices[kNumAceChoices] = {"1", "14"};
static const std::string kBuildChoices[kNumBuildChoices] = {"1", "2", "3"};
static const std::string kCaptureChoices[kNumCaptureChoices] = {"1", "2", "3"};
static const std::string kDeckChoices[kNumDeckChoices] = {"1", "2"};
static const std::string kLoadChoices[kNumLoadChoices] = {"1", "2"};

bool Sanitizer::MenuChoiceValid(const std::string& choice) {
  std::vector<std::string> tokens = TokenizeInput(choice);

  if (tokens.size() != 1) {
    return false;
  }

  for (unsigned i = 0; i < kMaxMenuChoices; i++) {
    if (tokens[0] == kMenuChoices[i]) {
      return true;
    }
  }

  return false;
}

bool Sanitizer::CardValid(const std::string& choice) {
  if (choice.length() != 2) {
    return false;
  }

  bool suit_valid = false;

  for (unsigned i = 0; i < Card::kNumSuits; i++) {
    if (choice[0] == kSuits[i]) {
      suit_valid = true;
    }
  }

  if (!suit_valid) {
    return false;
  }

  for (unsigned i = 0; i < Card::kNumValues; i++) {
    if (choice[1] == kValues[i]) {
      return true;
    }
  }

  return false;
}

std::vector<std::string> Sanitizer::TokenizeInput(const std::string& input) {
  std::vector<std::string> tokens;
  std::istringstream stream(input);

  std::copy(
      std::istream_iterator<std::string>(stream),
      std::istream_iterator<std::string>(), std::back_inserter(tokens));

  return tokens;
}

bool Sanitizer::CardChoiceValid(const std::string& choice) {
  std::vector<std::string> tokens = TokenizeInput(choice);

  if (tokens.size() != 1) {
    return false;
  }

  return CardValid(tokens[0]);
}

bool Sanitizer::ActionChoiceValid(const std::string& choice) {
  std::vector<std::string> tokens = TokenizeInput(choice);

  if (tokens.size() != 1) {
    return false;
  }

  for (unsigned i = 0; i < kNumMoveDirectives; i++) {
    if (tokens[0] == kMoveDirectives[i]) {
      return true;
    }
  }

  return false;
}

bool Sanitizer::BuildOptionValid(const std::string& option) {
  std::vector<std::string> tokens = TokenizeInput(option);

  if (tokens.size() != 1) {
    return false;
  }

  for (unsigned i = 0; i < kNumBuildChoices; i++) {
    if (tokens[0] == kBuildChoices[i]) {
      return true;
    }
  }

  return false;
}

bool Sanitizer::CoinChoiceValid(const std::string& choice) {
  std::vector<std::string> tokens = TokenizeInput(choice);

  if (tokens.size() != 1) {
    return false;
  }

  if (tokens[0] != "1" && tokens[0] != "0") {
    return false;
  }

  return true;
}

bool Sanitizer::CardsValid(
    const std::string& choice, std::vector<std::string>& cards) {
  std::vector<std::string> tokens = TokenizeInput(choice);

  if (tokens.empty()) {
    return true;
  }

  std::unordered_set<std::string> seen;

  for (unsigned i = 0; i < tokens.size(); i++) {
    if (seen.find(tokens[i]) != seen.end()) {
      return false;
    }

    seen.insert(tokens[i]);
  }

  for (std::string token : tokens) {
    if (!CardValid(token)) {
      return false;
    }
  }

  cards = tokens;

  return true;
}

bool Sanitizer::AceChoiceValid(const std::string& choice) {
  std::vector<std::string> tokens = TokenizeInput(choice);

  if (tokens.size() != 1) {
    return false;
  }

  for (unsigned i = 0; i < kNumAceChoices; i++) {
    if (tokens[0] == kAceChoices[i]) {
      return true;
    }
  }

  return false;
}

bool Sanitizer::CaptureChoiceValid(const std::string& choice) {
  std::vector<std::string> tokens = TokenizeInput(choice);

  if (tokens.size() != 1) {
    return false;
  }

  for (unsigned i = 0; i < kNumCaptureChoices; i++) {
    if (tokens[0] == kCaptureChoices[i]) {
      return true;
    }
  }

  return false;
}

bool Sanitizer::FileValid(const std::string& file_name) {
  std::vector<std::string> tokens = TokenizeInput(file_name);

  if (tokens.size() != 1) {
    return false;
  }

  unsigned index = file_name.find('.');

  if (index == std::string::npos) {
    return false;
  }

  if (file_name.substr(index + 1) != "txt") {
    return false;
  }

  return true;
}

bool Sanitizer::DeckChoiceValid(const std::string& choice) {
  std::vector<std::string> tokens = TokenizeInput(choice);

  if (tokens.size() != 1) {
    return false;
  }

  for (unsigned i = 0; i < kNumDeckChoices; i++) {
    if (tokens[0] == kDeckChoices[i]) {
      return true;
    }
  }

  return false;
}

bool Sanitizer::LoadChoiceValid(const std::string& choice) {
  std::vector<std::string> tokens = TokenizeInput(choice);

  if (tokens.size() != 1) {
    return false;
  }

  for (unsigned i = 0; i < kNumLoadChoices; i++) {
    if (tokens[0] == kLoadChoices[i]) {
      return true;
    }
  }

  return false;
}