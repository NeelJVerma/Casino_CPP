#ifndef _MOVE_H_
#define _MOVE_H_

#include <vector>
#include "card.h"
#include "build.h"

class Move {
 public:
  inline void AddLooseCard(const std::shared_ptr<Card>& card) {
    loose_cards_.push_back(card);
  }

  inline void AddSet(const std::vector<std::shared_ptr<Card>>& set) {
    sets_.push_back(set);
  }

  inline void AddBuild(const std::shared_ptr<Build>& build) {
    builds_.push_back(build);
  }

  inline std::vector<std::shared_ptr<Card>> GetLooseCards() const {
    return loose_cards_;
  }

  inline std::vector<std::vector<std::shared_ptr<Card>>> GetSets() const {
    return sets_;
  }

  inline std::vector<std::shared_ptr<Build>> GetBuilds() const {
    return builds_;
  }

 private:
  std::vector<std::shared_ptr<Card>> loose_cards_;
  std::vector<std::vector<std::shared_ptr<Card>>> sets_;
  std::vector<std::shared_ptr<Build>> builds_;
  unsigned priority_;
};

#endif