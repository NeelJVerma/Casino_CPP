/*******************************
 * Name: Neel Verma            *
 * Project: Casino CPP         *
 * Class: CMPS 366-01          *
 * Due Date: 10/2/18           *
 *******************************/

#include <iostream>
#include "gui.h"
#include "sanitizer.h"
#include "inputhandler.h"
#include "serializer.h"

/**
 * Description: Gets a string from stdin.
 * Parameters: None.
 * Returns: The entered string.
 */

std::string InputHandler::GetStringInput() {
  std::string choice;
  getline(std::cin, choice);

  return choice;
}

std::string InputHandler::GetCardInput() {
  std::string choice;

  while (true) {
    GUI::DisplayCardPlayMessage();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::CardChoiceValid(choice)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return choice;
}

unsigned InputHandler::GetAceInput(const std::string& card) {
  std::string choice;

  while (true) {
    GUI::DisplayAceChoiceMessage(card);
    choice = InputHandler::GetStringInput();

    if (Sanitizer::AceChoiceValid(choice)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return Serializer::GetIntFromString(choice);
}

unsigned InputHandler::GetActionInput() {
  std::string choice;

  while (true) {
    GUI::DisplayActionMenu();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::ActionChoiceValid(choice)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return Serializer::GetIntFromString(choice);
}

unsigned InputHandler::GetBuildInput() {
  std::string choice;

  while (true) {
    GUI::DisplayBuildMenu();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::BuildOptionValid(choice)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return Serializer::GetIntFromString(choice);
}

unsigned InputHandler::GetCaptureInput() {
  std::string choice;

  while (true) {
    GUI::DisplayCaptureMenu();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::CaptureChoiceValid(choice)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return Serializer::GetIntFromString(choice);
}

std::vector<std::string> InputHandler::GetBuildCardsInput() {
  std::string choice;
  std::vector<std::string> str_cards;

  while (true) {
    GUI::DisplayBuildCardsMessage();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::CardsValid(choice, str_cards)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return str_cards;
}

std::vector<std::string> InputHandler::GetBuildAddOnInput() {
  std::string choice;
  std::vector<std::string> str_cards;

  while (true) {
    GUI::DisplayBuildAddOnMessage();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::CardsValid(choice, str_cards)) {
      if (!str_cards.empty()) {
        break;
      }
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return str_cards;
}

std::vector<std::string> InputHandler::GetCaptureSetInput() {
  std::string choice;
  std::vector<std::string> str_cards;

  while (true) {
    GUI::DisplayCaptureSetMessage();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::CardsValid(choice, str_cards)) {
      if (!str_cards.empty()) {
        break;
      }
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return str_cards;
}

std::vector<std::string> InputHandler::GetCaptureBuildInput() {
  std::string choice;
  std::vector<std::string> str_cards;

  while (true) {
    GUI::DisplayCaptureBuildMessage();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::CardsValid(choice, str_cards)) {
      if (!str_cards.empty()) {
        break;
      }
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return str_cards;
}

std::string InputHandler::GetDiffCardInput() {
  GUI::DisplayPickDifferentCardMessage();

  return InputHandler::GetStringInput();
}

unsigned InputHandler::GetMenuInput() {
  std::string choice;

  while (true) {
    GUI::DisplayMenu();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::MenuChoiceValid(choice)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return Serializer::GetIntFromString(choice);
}

std::string InputHandler::GetFileInput() {
  std::string file_name;

  while (true) {
    GUI::DisplayFileMessage();
    file_name = InputHandler::GetStringInput();

    if (Sanitizer::FileValid(file_name)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return file_name;
}

unsigned InputHandler::GetDeckInput() {
  std::string choice;

  while (true) {
    GUI::DisplayDeckMenu();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::DeckChoiceValid(choice)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return Serializer::GetIntFromString(choice);
}

unsigned InputHandler::GetCoinInput() {
  std::string choice;

  while (true) {
    GUI::DisplayCoinMessage();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::CoinChoiceValid(choice)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return Serializer::GetIntFromString(choice);
}

unsigned InputHandler::GetLoadChoiceInput() {
  std::string choice;

  while (true) {
    GUI::DisplayLoadMenu();
    choice = InputHandler::GetStringInput();

    if (Sanitizer::LoadChoiceValid(choice)) {
      break;
    }

    GUI::DisplayInvalidChoiceMessage();
  }

  return Serializer::GetIntFromString(choice);
}