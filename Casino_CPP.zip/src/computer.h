#ifndef _COMPUTER_H_
#define _COMPUTER_H_

#include "player.h"
#include "move.h"

class Computer : public Player {
 public:
  using Player::Player;
  bool MakeMove(std::shared_ptr<Table>& table);

 private:
  std::shared_ptr<Move> best_move_;
  void FindBestMove(std::shared_ptr<Table>& table);
  void FindBestMoveWithCard(const std::shared_ptr<Card>& card,
      const std::shared_ptr<Table>& table) const;

  void FindAllSubsetsWithCard(const std::shared_ptr<Card>& card,
      const std::shared_ptr<Table>& table) const;

  void FindAllLooseCardsWithCard(const std::shared_ptr<Card>& card,
      const std::shared_ptr<Table>& table) const;

  void FindAllBuildsWithCard(const std::shared_ptr<Card>& card,
      const std::shared_ptr<Table>& table) const;
};

#endif